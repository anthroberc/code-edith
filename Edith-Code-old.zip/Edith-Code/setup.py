
from setuptools import setup, find_packages

setup(
    name="code-edith",
    version="1.1.0",
    # This tells pip to look in the current directory for scripts
    py_modules=["index"], 
    packages=find_packages(),
    install_requires=[
        "openai==2.24.0",
        "python-dotenv==1.2.1",
        "rich==14.3.3",
        "ddgs==9.10.0",
    ],
    entry_points={
        'console_scripts': [
            'code-edith=index:main',
        ],
    },
)
