import os
from rich.text import Text
from rich.console import Console
from bin.helper.banner import banner
from bin.chat import auth, chat
from dotenv import load_dotenv

def main():
    # 1. Load configuration from Home Directory
    env_path = os.path.expanduser("~/.env")
    load_dotenv(env_path)
    
    # 2. Initialize Session
    console = Console()
    history = []
    
    key = os.environ.get('EDITH_API')
    url = os.environ.get('EDITH_URL')
    model = os.environ.get('EDITH_MODEL')
    ORANGE_STYLE = "rgb(217,119,87)"
    
    banner()
    client = auth(key, url)
    
    # 3. Main Loop
    while True:
        # Grey '>' for user input
        query = input("\033[90m>\033[0m ")
        
        if query.lower() in ['/exit', 'exit']:
            break
        
        # Generate Response
        result = chat(client, query, history, model)
        
        # Orange '>' for Edith (Fixed syntax error here)
        console.print(Text("> ", style=ORANGE_STYLE), end="")
        
        full_response = ""
        for chunk in result:
            content = chunk.choices[0].delta.content
            if content:
                print(content, end="", flush=True)
                full_response += content
        print('\n')
        
        # Privacy on Top: History stays in RAM
        history.append({"role": "user", "content": query})
        history.append({"role": "assistant", "content": full_response})

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nSession terminated.")
    except Exception as e:
        print(f"\nError: {e}")